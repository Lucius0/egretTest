var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var Main = (function (_super) {
    __extends(Main, _super);
    function Main() {
        _super.call(this);
        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddToStage, this);
    }
    Main.prototype.onAddToStage = function (event) {
        //初始化Resource资源加载库
        RES.addEventListener(RES.ResourceEvent.CONFIG_COMPLETE, this.onConfigComplete, this);
        RES.loadConfig("resource/resource.json", "resource/");
    };

    /**
    * 配置文件加载完成,开始预加载preload资源组。
    */
    Main.prototype.onConfigComplete = function (event) {
        RES.removeEventListener(RES.ResourceEvent.CONFIG_COMPLETE, this.onConfigComplete, this);
        RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.createGameScene, this);
        RES.loadGroup("preload");
    };

    Main.prototype.createGameScene = function (event) {
        RES.removeEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.createGameScene, this);

        //画一个加载的按钮
        var sp = new egret.Sprite();
        sp.graphics.beginFill(0xFFFFFF);
        sp.graphics.drawRect(0, 0, 100, 50);
        sp.x = 10;
        sp.y = 10;
        sp.width = 100;
        sp.height = 50; //设置点击区域
        sp.touchEnabled = true; //可点击
        this.addChild(sp);

        //第1个按钮的说明文字
        var txt1 = new egret.TextField();
        txt1.text = "点击加载第1波30个资源图片";
        txt1.x = 120;
        txt1.y = 10;
        this.addChild(txt1);

        //第一个loading条
        this.load = new Load();
        this.load.x = this.stage.width / 2;
        this.load.y = 110;
        this.addChild(this.load);

        //点击开始加载
        sp.addEventListener(egret.TouchEvent.TOUCH_TAP, this.startLoad, this);
    };
    Main.prototype.startLoad = function () {
        this.load.startLoad(); //点击开始加载
    };
    return Main;
})(egret.DisplayObjectContainer);
Main.prototype.__class__ = "Main";
