var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var Load1 = (function (_super) {
    __extends(Load1, _super);
    function Load1() {
        _super.call(this);
        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddToStage, this);
    }
    Load1.prototype.onAddToStage = function () {
        this.x = this.stage.stageWidth / 2;

        //底部的进度条
        var dark = new egret.Bitmap(RES.getRes("bardark"));
        dark.x = -dark.width / 2;
        this.addChild(dark);

        //上面的进度条
        this.bright = new egret.Bitmap(RES.getRes("barbright"));
        this.bright.x = -this.bright.width / 2;
        this.addChild(this.bright);

        this.maskRect = new egret.Rectangle(0, 0, 0, 24);
        this.bright.mask = this.maskRect; //设置空的遮罩，亮条不显示

        this.txt = new egret.TextField();
        this.txt.width = 200;
        this.txt.textAlign = "center";
        this.txt.text = "0/30";
        this.txt.x = -100;
        this.txt.y = -40;

        this.addChild(this.txt);
    };
    Load1.prototype.startLoad = function () {
        RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.onLoadEnd, this);
        RES.addEventListener(RES.ResourceEvent.GROUP_PROGRESS, this.onProgress, this);
        RES.loadGroup("x30");
    };

    /**
    * 加载资源文件中
    */
    Load1.prototype.onProgress = function (event) {
        this.txt.text = event.itemsLoaded.toString() + "/" + event.itemsTotal.toString();
        var per = event.itemsLoaded / event.itemsTotal;
        this.maskRect = new egret.Rectangle(0, 0, per * 256, 24); //计算遮罩的大小
        this.bright.mask = this.maskRect;
    };

    /**
    * 加载资源文件结束
    */
    Load1.prototype.onLoadEnd = function () {
    };
    return Load1;
})(egret.DisplayObjectContainer);
