class Main extends egret.DisplayObjectContainer{
    public constructor() {
        super();
        this.addEventListener(egret.Event.ADDED_TO_STAGE,this.onAddToStage,this);
    }

    private onAddToStage(event:egret.Event){
        //初始化Resource资源加载库
        RES.addEventListener(RES.ResourceEvent.CONFIG_COMPLETE,this.onConfigComplete,this);
        RES.loadConfig("resource/resource.json","resource/");
    }
    /**
     * 配置文件加载完成,开始预加载preload资源组。
     */
    private onConfigComplete(event:RES.ResourceEvent):void{
        RES.removeEventListener(RES.ResourceEvent.CONFIG_COMPLETE,this.onConfigComplete,this);
        RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE,this.createGameScene,this);
        RES.loadGroup("preload");
    }
    /**
     * preload资源组家在结束,创建游戏场景
     */
    private load:Load;
    private createGameScene(event:RES.ResourceEvent):void{
        RES.removeEventListener(RES.ResourceEvent.GROUP_COMPLETE,this.createGameScene,this);
        //画一个加载的按钮
        var sp:egret.Sprite = new egret.Sprite();
        sp.graphics.beginFill(0xFFFFFF);
        sp.graphics.drawRect(0,0,100,50);
        sp.x=10;sp.y=10;
        sp.width = 100; sp.height =50;//设置点击区域
        sp.touchEnabled= true;//可点击
        this.addChild(sp);
        
        //第1个按钮的说明文字
        var txt1:egret.TextField = new egret.TextField();
        txt1.text = "点击加载第1波30个资源图片";
        txt1.x=120; txt1.y=10;
        this.addChild(txt1);
        //第一个loading条
        this.load = new Load();
        this.load.x = this.stage.width/2; this.load.y = 110;
        this.addChild(this.load);
        //点击开始加载
        sp.addEventListener(egret.TouchEvent.TOUCH_TAP,this.startLoad,this);
    }
    private startLoad():void{
        this.load.startLoad();//点击开始加载
    }
}


