class Load extends egret.DisplayObjectContainer{
    private maskRect:egret.Rectangle;
    private txt:egret.TextField;
    private bright:egret.Bitmap;
    public constructor() {
        super();
        this.addEventListener(egret.Event.ADDED_TO_STAGE,this.onAddToStage,this);
    }
    public onAddToStage():void{
        this.x = this.stage.stageWidth/2;
        //底部的进度条
        var dark:egret.Bitmap = new egret.Bitmap(RES.getRes("bardark"));
        dark.x = -dark.width/2; 
        this.addChild(dark);
        //上面的进度条
        this.bright = new egret.Bitmap(RES.getRes("barbright"));
        this.bright.x = -this.bright.width/2;
        this.addChild(this.bright);
        
        this.maskRect = new egret.Rectangle(0,0,0,24);
        this.bright.mask = this.maskRect;//设置空的遮罩，亮条不显示
        
        this.txt = new egret.TextField();
        this.txt.width=400;
        this.txt.textAlign = "center";
        this.txt.text = "0/30";
        this.txt.x =-200;
        this.txt.y=-40;
        
        this.addChild(this.txt);
    }
    public startLoad():void{
        RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE,this.onLoadEnd,this);
        RES.addEventListener(RES.ResourceEvent.GROUP_PROGRESS,this.onProgress,this);
        RES.loadGroup("x30");
    }
    /**
     * 加载资源文件中
     */
    public onProgress(event:RES.ResourceEvent):void{
        this.txt.text = event.itemsLoaded.toString()+"/"+event.itemsTotal.toString();
        var per:number = event.itemsLoaded/event.itemsTotal;//加载的比例
        this.maskRect = new egret.Rectangle(0,0,per*256,24);//计算遮罩的大小
        this.bright.mask = this.maskRect;
    }
    /**
     * 加载资源文件结束
     */
    public onLoadEnd():void{
        this.txt.text = "30/30 加载结束"
    }
}